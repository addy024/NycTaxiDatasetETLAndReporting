// Databricks notebook source
// MAGIC %sql
// MAGIC CREATE DATABASE IF NOT EXISTS TaxiServiceWarehouse

// COMMAND ----------

dbutils.widgets.text("ProcessMonth", "202202", "Process Month (yyyymm)")

var processMonth = dbutils.widgets.get("ProcessMonth")

// COMMAND ----------

// Create a parameter mapping to be passed to the callee notebook
var parametersMap = Map(
                      "ProcessMonth" -> processMonth
                    )

// Invoke all dimension notebooks
var status = dbutils.notebook.run("/ETLpipeline/Dimensions/ProcessDimTaxiZones", 60, Map())
status = dbutils.notebook.run("/ETLpipeline/Dimensions/ProcessDimRateCodes", 60, Map())
status = dbutils.notebook.run("/ETLpipeline/Dimensions/ProcessDimPaymentTypes", 60, Map())
status = dbutils.notebook.run("/ETLpipeline/Dimensions/ProcessDimBases", 60, Map())

// Invoke all fact notebooks
status = dbutils.notebook.run("/ETLpipeline/Facts/ProcessFactYellowTaxiTripData", 300, parametersMap)
status = dbutils.notebook.run("/ETLpipeline/Facts/ProcessFactGreenTaxiTripData", 300, parametersMap)
status = dbutils.notebook.run("/ETLpipeline/Facts/ProcessFactFHVTaxiTripData", 300, parametersMap)

// COMMAND ----------

