-- Databricks notebook source
show databases;

-- COMMAND ----------

use taxiservicewarehouse

-- COMMAND ----------

show tables;

-- COMMAND ----------

-- DBTITLE 1,Total Amount Earn by Yellow Taxi Trip in Year 2022 Month Feb 
select sum(TotalAmount) as Total from factyellowtaxitripdata;

-- COMMAND ----------

-- DBTITLE 1,Total Amount Earn by Green Taxi Trip in Year 2022 Month Feb
select sum(TotalAmount) as Total from factgreentaxitripdata;

-- COMMAND ----------

-- DBTITLE 1,Brooklyn has a highest Count To For Hire Cars 
select * from dimfhvbases;

-- COMMAND ----------

-- DBTITLE 1,Distribution of Records Geographically (FHVBase)
select * from dimfhvbases;

-- COMMAND ----------

-- DBTITLE 1,Distribution of BaseType
select BaseType, count(*) as count from dimfhvbases
Group by BaseType;

-- COMMAND ----------

-- DBTITLE 1,Most of the Trips which are taken are SoloTrip
select * from 
factyellowtaxitripdata;

-- COMMAND ----------

-- DBTITLE 1,On Average Cost of Solo vs Shared Trip in Yellow Taxi
select * from 
factyellowtaxitripdata;

-- COMMAND ----------

-- DBTITLE 1,Distribution of Trip time in minutes for Yellow taxi trip 
select * from factyellowtaxitripdata 
;

-- COMMAND ----------

select * from 
factgreentaxitripdata;

-- COMMAND ----------

select * from 
factgreentaxitripdata;

-- COMMAND ----------

-- DBTITLE 1,Distribution of Trip time in minutes for Green taxi trip 
select * from 
factgreentaxitripdata;

-- COMMAND ----------

-- DBTITLE 1,Green Taxi Trip Payment Type Distribution
select dimpaymenttypes.PaymentType,  sum(factgreentaxitripdata.TotalAmount) as Total from factgreentaxitripdata inner join dimpaymenttypes on factgreentaxitripdata.PaymentType = dimpaymenttypes.PaymentTypeID 
group by dimpaymenttypes.PaymentType
order by Total Desc;

-- COMMAND ----------

-- DBTITLE 1,Average Amount of Payment Type in Green Taxi Trip 
select dimpaymenttypes.PaymentType,  avg(factgreentaxitripdata.TotalAmount) as AverageAmount from factgreentaxitripdata inner join dimpaymenttypes on factgreentaxitripdata.PaymentType = dimpaymenttypes.PaymentTypeID 
group by dimpaymenttypes.PaymentType
order by AverageAmount Desc;

-- COMMAND ----------

-- DBTITLE 1,Total Amount Distribution according to Borough Green Taxi Trips
select dimtaxizones.Borough ,sum(factgreentaxitripdata.TotalAmount) as TotalAmount from factgreentaxitripdata inner join dimtaxizones on factgreentaxitripdata.PickupLocationId = dimtaxizones.LocationID 
Group BY dimtaxizones.Borough;

-- COMMAND ----------

